#!/bin/bash
ngrok -config=./ngrok.cfg -subdomain gxz 3000
